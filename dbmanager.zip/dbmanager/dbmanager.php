<?php

/*
  Plugin Name: DataBaseBrowser
  Plugin URI:www.w3schools.com
  Description: a plugin to view database content
  Version: 1.0
  Author: Mr. aloshacorshak
  Author URI: www.w3schools.com
  License: GPL2
  */




    function plugin_main_menu(){
        add_menu_page('My Custom Page', 'DBManager', 'manage_options', 'my-top-level-slug');
        add_submenu_page( 'my-top-level-slug', 'My Custom Page', 'FaceBook',
            'manage_options', 'my-top-level-slug','facebookpage');
        add_submenu_page( 'my-top-level-slug', 'Istagram', 'Istagram',
            'manage_options', 'my-secondary-slug','istagrampage');
        add_submenu_page( 'my-top-level-slug', 'Google', 'Google+',
            'manage_options', 'my-third-slug','googlepage');
        add_submenu_page( 'my-top-level-slug', 'Youtube', 'Youtube',
            'manage_options', 'my-four-slug','youtubepage');
        add_submenu_page( 'my-top-level-slug', 'Twitter', 'Twitter',
            'manage_options', 'my-five-slug','twitterpage');
        add_submenu_page( 'my-top-level-slug', 'SoundCloud', 'SoundCloud',
            'manage_options', 'my-six-slug','soundpage');

    }
function my_custom_css() {
    echo '<link rel="stylesheet" href="../wp-content/plugins/dbmanager/css/bootstrap.css" type="text/css" media="all" />';
    echo '<link rel="stylesheet" href="../wp-content/plugins/dbmanager/css/boo.css" type="text/css" media="all" />';


}
add_action('admin_head', 'my_custom_css');

function my_custom_js(){
    echo '<script src="../wp-content/plugins/dbmanager/js/jquery-2.1.0.min.js"></script>';
    echo '<script src="../wp-content/plugins/dbmanager/js/bootstrap.js"></script>';
    echo '<script src="../wp-content/plugins/dbmanager/js/jquery.dataTables.js"></script>';
    echo '<script src="../wp-content/plugins/dbmanager/js/DT_bootstrap.js"></script>';
    echo '<script src="../wp-content/plugins/dbmanager/js/table-editable.js"></script>';
    echo'<script> EditableTable.init();</script>';
}

add_action('admin_footer','my_custom_js');

function facebookpage(){

       global $wpdb;




/**
 * Fires before each tab on the Install Plugins screen is loaded.
 *
 * The dynamic portion of the action hook, `$tab`, allows for targeting
 * individual tabs, for instance 'install_plugins_pre_plugin-information'.
 *
 * @since 2.7.0
 */


/**
 * WordPress Administration Template Header.
 */



?>

<div class="wrap">
    <h1>
        FaceBook-related tables
    </h1>


    <div class="row-fluid">
        <hr class="margin-xxx">
        <div class="span11">
            <div class="tabbable tabs-left">
                <ul class="nav nav-tabs">
                    <li><a href="#TabLeft1" data-toggle="tab">WP_FACEBOOK</a></li>
                    <li><a href="#TabLeft2" data-toggle="tab">WP_POSTMETA</a></li>
                    <li class="active"><a href="#TabLeft3" data-toggle="tab">WP_USERMETA</a></li>
                    <li><a href="#TabLeft4" data-toggle="tab">WP_POSTS</a></li>
                    <li><a href="#TabLeft5" data-toggle="tab">WP_OPTION</a></li>
                    <li><a href="#TabLeft6" data-toggle="tab">WP_POSTS</a></li>
                    <li><a href="#TabLeft7" data-toggle="tab">WP_COMMENTS</a></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane" id="TabLeft1">
                        <div class="well well-nice">
                            <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample">
                                <caption>
                                    CONTENT OF WP_FACEBOOK CUSTOM TABLE <span>Long content</span>
                                </caption>
                                <thead>
                                <?php
                                $sql = "SELECT * FROM wp_facebook";
                                $results = $wpdb->get_results( $sql );
                                if(count($results)!=0)
                                {
                                $results[0];
                                $temparraykey=array_keys(get_object_vars($results[0]));?>
                                <tr>
                                    <?php
                                    foreach($temparraykey as $temp){
                                        echo'<th scope="col">'. $temp.'</th>';
                                    };
                                    ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($results as $result){
                                    echo '<tr>';
                                    foreach(get_object_vars($result) as $tempresultvalue){
                                        echo '<td>'.$tempresultvalue.'</td>';
                                    }
                                    echo '</tr>';
                                }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- // tab 1 -->
                    <div class="tab-pane" id="TabLeft2">
                        <div class="well well-nice">
                            <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample2">
                                <caption>
                                    CONTENT OF WP_POSTMETA DEFAULT TABLE <span>Long content</span>
                                </caption>
                                <thead>
                                <?php
                                $sql = "SELECT * FROM wp_postmeta";
                                $results = $wpdb->get_results( $sql );
                                if(count($results)!=0)
                                {
                                $results[0];
                                $temparraykey=array_keys(get_object_vars($results[0]));?>
                                <tr>
                                    <?php
                                    foreach($temparraykey as $temp){
                                        echo'<th scope="col">'. $temp.'</th>';
                                    };
                                    ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($results as $result){
                                    echo '<tr>';
                                    foreach(get_object_vars($result) as $tempresultvalue){
                                        echo '<td>'.$tempresultvalue.'</td>';
                                    }
                                    echo '</tr>';
                                }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- // tab 2 -->

                    <div class="tab-pane active" id="TabLeft3">
                        <div class="well well-nice">
                            <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample3">
                                <caption>
                                    CONTENT OF WP_USERMETA DEFAULT TABLE<span>Long content</span>
                                </caption>
                                <thead>
                                <?php
                                $sql = "SELECT * FROM wp_usermeta";
                                $results = $wpdb->get_results( $sql );
                                if(count($results)!=0)
                                {
                                $results[0];
                                $temparraykey=array_keys(get_object_vars($results[0]));?>
                                <tr>
                                    <?php
                                    foreach($temparraykey as $temp){
                                        echo'<th scope="col">'. $temp.'</th>';
                                    };
                                    ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($results as $result){
                                    echo '<tr>';
                                    foreach(get_object_vars($result) as $tempresultvalue){
                                        echo '<td>'.$tempresultvalue.'</td>';
                                    }
                                    echo '</tr>';
                                }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="TabLeft4">
                        <div class="well well-nice">
                            <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample4">
                                <caption>
                                    CONTENT OF WP_POSTS DEFAULT TABLE<span>Long content</span>
                                </caption>
                                <thead>
                                <?php
                                $sql = "SELECT * FROM wp_posts";
                                $results = $wpdb->get_results( $sql );
                                if(count($results)!=0)
                                {
                                $results[0];
                                $temparraykey=array_keys(get_object_vars($results[0]));?>
                                <tr>
                                    <?php
                                    foreach($temparraykey as $temp){
                                        echo'<th scope="col">'. $temp.'</th>';
                                    };
                                    ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($results as $result){
                                    echo '<tr>';
                                    foreach(get_object_vars($result) as $tempresultvalue){
                                        echo '<td>'.$tempresultvalue.'</td>';
                                    }
                                    echo '</tr>';
                                }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="TabLeft5">
                        <div class="well well-nice">
                            <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample5">
                                <caption>
                                    CONTENT OF WP_OPTIONS DEFAULT TABLE<span>Long content</span>
                                </caption>
                                <thead>
                                <?php
                                $sql = "SELECT * FROM wp_options";
                                $results = $wpdb->get_results( $sql );
                                if(count($results)!=0)
                                {
                                $results[0];
                                $temparraykey=array_keys(get_object_vars($results[0]));?>
                                <tr>
                                    <?php
                                    foreach($temparraykey as $temp){
                                        echo'<th scope="col">'. $temp.'</th>';
                                    };
                                    ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($results as $result){
                                    echo '<tr>';
                                    foreach(get_object_vars($result) as $tempresultvalue){
                                        echo '<td>'.$tempresultvalue.'</td>';
                                    }
                                    echo '</tr>';
                                }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane" id="TabLeft6">
                        <div class="well well-nice">
                            <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample6">
                                <caption>
                                    CONTENT OF WP_POSTS DEFAULT TABLE <span>Long content</span>
                                </caption>
                                <thead>
                                <?php
                                $sql = "SELECT * FROM wp_posts";
                                $results = $wpdb->get_results( $sql );
                                if(count($results)!=0)
                                {
                                $results[0];
                                $temparraykey=array_keys(get_object_vars($results[0]));?>
                                <tr>
                                    <?php
                                    foreach($temparraykey as $temp){
                                        echo'<th scope="col">'. $temp.'</th>';
                                    };
                                    ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($results as $result){
                                    echo '<tr>';
                                    foreach(get_object_vars($result) as $tempresultvalue){
                                        echo '<td>'.$tempresultvalue.'</td>';
                                    }
                                    echo '</tr>';
                                }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- // tab 3 -->
                    <div class="tab-pane" id="TabLeft7">
                        <div class="well well-nice">
                            <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample7">
                                <caption>
                                    CONTENT OF WP_COMMENTS DEFAULT TABLE<span>Long content</span>
                                </caption>
                                <thead>
                                <?php
                                $sql = "SELECT * FROM wp_comments";
                                $results = $wpdb->get_results( $sql );
                                if(count($results)!=0)
                                {
                                $results[0];
                                $temparraykey=array_keys(get_object_vars($results[0]));?>
                                <tr>
                                    <?php
                                    foreach($temparraykey as $temp){
                                        echo'<th scope="col">'. $temp.'</th>';
                                    };
                                    ?>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach($results as $result){
                                    echo '<tr>';
                                    foreach(get_object_vars($result) as $tempresultvalue){
                                        echo '<td>'.$tempresultvalue.'</td>';
                                    }
                                    echo '</tr>';
                                }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
            <!-- // Tabs LEFT - Base -->

        </div>
    </div>


</div>
<?php
}
function istagrampage(){






    /**
     * Fires before each tab on the Install Plugins screen is loaded.
     *
     * The dynamic portion of the action hook, `$tab`, allows for targeting
     * individual tabs, for instance 'install_plugins_pre_plugin-information'.
     *
     * @since 2.7.0
     */


    /**
     * WordPress Administration Template Header.
     */

    global $wpdb;

    ?>

    <div class="wrap">
        <h1>
            FaceBook-related tables
        </h1>


        <div class="row-fluid">
            <hr class="margin-xxx">
            <div class="span11">
                <div class="tabbable tabs-left">
                    <ul class="nav nav-tabs">
                        <li><a href="#TabLeft1" data-toggle="tab">WP_FACEBOOK</a></li>
                        <li><a href="#TabLeft2" data-toggle="tab">WP_POSTMETA</a></li>
                        <li class="active"><a href="#TabLeft3" data-toggle="tab">WP_USERMETA</a></li>
                        <li><a href="#TabLeft4" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft5" data-toggle="tab">WP_OPTION</a></li>
                        <li><a href="#TabLeft6" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft7" data-toggle="tab">WP_COMMENTS</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane" id="TabLeft1">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample">
                                    <caption>
                                        CONTENT OF WP_FACEBOOK CUSTOM TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_facebook";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 1 -->
                        <div class="tab-pane" id="TabLeft2">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample2">
                                    <caption>
                                        CONTENT OF WP_POSTMETA DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_postmeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 2 -->

                        <div class="tab-pane active" id="TabLeft3">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample3">
                                    <caption>
                                        CONTENT OF WP_USERMETA DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_usermeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft4">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample4">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft5">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample5">
                                    <caption>
                                        CONTENT OF WP_OPTIONS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_options";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft6">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample6">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 3 -->
                        <div class="tab-pane" id="TabLeft7">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample7">
                                    <caption>
                                        CONTENT OF WP_COMMENTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_comments";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- // Tabs LEFT - Base -->

            </div>
        </div>


    </div>
<?php
}
function googlepage(){



    global $wpdb;


    /**
     * Fires before each tab on the Install Plugins screen is loaded.
     *
     * The dynamic portion of the action hook, `$tab`, allows for targeting
     * individual tabs, for instance 'install_plugins_pre_plugin-information'.
     *
     * @since 2.7.0
     */


    /**
     * WordPress Administration Template Header.
     */



    ?>

    <div class="wrap">
        <h1>
            FaceBook-related tables
        </h1>


        <div class="row-fluid">
            <hr class="margin-xxx">
            <div class="span11">
                <div class="tabbable tabs-left">
                    <ul class="nav nav-tabs">
                        <li><a href="#TabLeft1" data-toggle="tab">WP_FACEBOOK</a></li>
                        <li><a href="#TabLeft2" data-toggle="tab">WP_POSTMETA</a></li>
                        <li class="active"><a href="#TabLeft3" data-toggle="tab">WP_USERMETA</a></li>
                        <li><a href="#TabLeft4" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft5" data-toggle="tab">WP_OPTION</a></li>
                        <li><a href="#TabLeft6" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft7" data-toggle="tab">WP_COMMENTS</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane" id="TabLeft1">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample">
                                    <caption>
                                        CONTENT OF WP_FACEBOOK CUSTOM TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_facebook";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 1 -->
                        <div class="tab-pane" id="TabLeft2">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample2">
                                    <caption>
                                        CONTENT OF WP_POSTMETA DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_postmeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 2 -->

                        <div class="tab-pane active" id="TabLeft3">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample3">
                                    <caption>
                                        CONTENT OF WP_USERMETA DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_usermeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft4">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample4">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft5">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample5">
                                    <caption>
                                        CONTENT OF WP_OPTIONS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_options";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft6">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample6">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 3 -->
                        <div class="tab-pane" id="TabLeft7">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample7">
                                    <caption>
                                        CONTENT OF WP_COMMENTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_comments";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- // Tabs LEFT - Base -->

            </div>
        </div>


    </div>
<?php
}
function youtubepage(){


    global $wpdb;



    /**
     * Fires before each tab on the Install Plugins screen is loaded.
     *
     * The dynamic portion of the action hook, `$tab`, allows for targeting
     * individual tabs, for instance 'install_plugins_pre_plugin-information'.
     *
     * @since 2.7.0
     */


    /**
     * WordPress Administration Template Header.
     */



    ?>

    <div class="wrap">
        <h1>
            FaceBook-related tables
        </h1>


        <div class="row-fluid">
            <hr class="margin-xxx">
            <div class="span11">
                <div class="tabbable tabs-left">
                    <ul class="nav nav-tabs">
                        <li><a href="#TabLeft1" data-toggle="tab">WP_FACEBOOK</a></li>
                        <li><a href="#TabLeft2" data-toggle="tab">WP_POSTMETA</a></li>
                        <li class="active"><a href="#TabLeft3" data-toggle="tab">WP_USERMETA</a></li>
                        <li><a href="#TabLeft4" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft5" data-toggle="tab">WP_OPTION</a></li>
                        <li><a href="#TabLeft6" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft7" data-toggle="tab">WP_COMMENTS</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane" id="TabLeft1">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample">
                                    <caption>
                                        CONTENT OF WP_FACEBOOK CUSTOM TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_facebook";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 1 -->
                        <div class="tab-pane" id="TabLeft2">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample2">
                                    <caption>
                                        CONTENT OF WP_POSTMETA DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_postmeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 2 -->

                        <div class="tab-pane active" id="TabLeft3">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample3">
                                    <caption>
                                        CONTENT OF WP_USERMETA DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_usermeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft4">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample4">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft5">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample5">
                                    <caption>
                                        CONTENT OF WP_OPTIONS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_options";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft6">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample6">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 3 -->
                        <div class="tab-pane" id="TabLeft7">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample7">
                                    <caption>
                                        CONTENT OF WP_COMMENTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_comments";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- // Tabs LEFT - Base -->

            </div>
        </div>


    </div>
<?php
}
function twitterpage(){

    global $wpdb;




    /**
     * Fires before each tab on the Install Plugins screen is loaded.
     *
     * The dynamic portion of the action hook, `$tab`, allows for targeting
     * individual tabs, for instance 'install_plugins_pre_plugin-information'.
     *
     * @since 2.7.0
     */


    /**
     * WordPress Administration Template Header.
     */



    ?>

    <div class="wrap">
        <h1>
            FaceBook-related tables
        </h1>


        <div class="row-fluid">
            <hr class="margin-xxx">
            <div class="span11">
                <div class="tabbable tabs-left">
                    <ul class="nav nav-tabs">
                        <li><a href="#TabLeft1" data-toggle="tab">WP_FACEBOOK</a></li>
                        <li><a href="#TabLeft2" data-toggle="tab">WP_POSTMETA</a></li>
                        <li class="active"><a href="#TabLeft3" data-toggle="tab">WP_USERMETA</a></li>
                        <li><a href="#TabLeft4" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft5" data-toggle="tab">WP_OPTION</a></li>
                        <li><a href="#TabLeft6" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft7" data-toggle="tab">WP_COMMENTS</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane" id="TabLeft1">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample">
                                    <caption>
                                        CONTENT OF WP_FACEBOOK CUSTOM TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_facebook";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 1 -->
                        <div class="tab-pane" id="TabLeft2">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample2">
                                    <caption>
                                        CONTENT OF WP_POSTMETA DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_postmeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 2 -->

                        <div class="tab-pane active" id="TabLeft3">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample3">
                                    <caption>
                                        CONTENT OF WP_USERMETA DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_usermeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft4">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample4">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft5">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample5">
                                    <caption>
                                        CONTENT OF WP_OPTIONS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_options";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft6">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample6">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 3 -->
                        <div class="tab-pane" id="TabLeft7">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample7">
                                    <caption>
                                        CONTENT OF WP_COMMENTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_comments";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- // Tabs LEFT - Base -->

            </div>
        </div>


    </div>
<?php
}
function soundpage(){


    global $wpdb;



    /**
     * Fires before each tab on the Install Plugins screen is loaded.
     *
     * The dynamic portion of the action hook, `$tab`, allows for targeting
     * individual tabs, for instance 'install_plugins_pre_plugin-information'.
     *
     * @since 2.7.0
     */


    /**
     * WordPress Administration Template Header.
     */



    ?>

    <div class="wrap">
        <h1>
            FaceBook-related tables
        </h1>


        <div class="row-fluid">
            <hr class="margin-xxx">
            <div class="span11">
                <div class="tabbable tabs-left">
                    <ul class="nav nav-tabs">
                        <li><a href="#TabLeft1" data-toggle="tab">WP_FACEBOOK</a></li>
                        <li><a href="#TabLeft2" data-toggle="tab">WP_POSTMETA</a></li>
                        <li class="active"><a href="#TabLeft3" data-toggle="tab">WP_USERMETA</a></li>
                        <li><a href="#TabLeft4" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft5" data-toggle="tab">WP_OPTION</a></li>
                        <li><a href="#TabLeft6" data-toggle="tab">WP_POSTS</a></li>
                        <li><a href="#TabLeft7" data-toggle="tab">WP_COMMENTS</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane" id="TabLeft1">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample">
                                    <caption>
                                        CONTENT OF WP_FACEBOOK CUSTOM TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_facebook";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 1 -->
                        <div class="tab-pane" id="TabLeft2">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample2">
                                    <caption>
                                        CONTENT OF WP_POSTMETA DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_postmeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 2 -->

                        <div class="tab-pane active" id="TabLeft3">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample3">
                                    <caption>
                                        CONTENT OF WP_USERMETA DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_usermeta";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft4">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample4">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft5">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample5">
                                    <caption>
                                        CONTENT OF WP_OPTIONS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_options";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="TabLeft6">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample6">
                                    <caption>
                                        CONTENT OF WP_POSTS DEFAULT TABLE <span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_posts";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- // tab 3 -->
                        <div class="tab-pane" id="TabLeft7">
                            <div class="well well-nice">
                                <table class="table boo-table table-striped table-condensed bg-blue-medium" id="editable-sample7">
                                    <caption>
                                        CONTENT OF WP_COMMENTS DEFAULT TABLE<span>Long content</span>
                                    </caption>
                                    <thead>
                                    <?php
                                    $sql = "SELECT * FROM wp_comments";
                                    $results = $wpdb->get_results( $sql );
                                    if(count($results)!=0)
                                    {
                                    $results[0];
                                    $temparraykey=array_keys(get_object_vars($results[0]));?>
                                    <tr>
                                        <?php
                                        foreach($temparraykey as $temp){
                                            echo'<th scope="col">'. $temp.'</th>';
                                        };
                                        ?>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    foreach($results as $result){
                                        echo '<tr>';
                                        foreach(get_object_vars($result) as $tempresultvalue){
                                            echo '<td>'.$tempresultvalue.'</td>';
                                        }
                                        echo '</tr>';
                                    }
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- // Tabs LEFT - Base -->

            </div>
        </div>


    </div>
<?php
}
add_action('admin_menu','plugin_main_menu');

?>



